import os
from setuptools import find_packages, setup

with open(os.path.join(os.path.dirname(__file__), 'README.rst')) as readme:
    README = readme.read()

    os.chdir(os.path.normpath(os.path.join(os.path.abspath(__file__), os.pardir)))

    setup(
        name='django-ex00',
        version='0.1',
        packages=find_packages(),
        include_package_data=True,
        license='CC BY-SA 4.0',
        description="A simple Django app to view the uploaded files.",
        long_description=README,
        url='',
        author='omaslova',
        author_email='omaslova@student.unit.ua',
        classifiers=[
            'Environment :: Web Environment',
            'Framework:: Django',
            'Framework:: Django:: 3.0.3',
            'Intended Audience:: Developers',
            'License:: CC BY-SA 4.0',
            'Operating System:: OS Independent',
            'Programming Language:: Python',
            'Programming Language:: Python:: 3',
            'Programming Language:: Python:: 3.6',
            'Programming Language:: Python:: 3.7',
            'Programming Language:: Python:: 3.8',
            'Topic:: Internet:: WWW / HTTP',
            'Topic:: Internet:: WWW / HTTP:: Dynamic Content',
        ],
        install_requires=['asgiref==3.2.3',
                          'Django==3.0.3',
                          'psycopg2-binary==2.8.4',
                          'pytz==2019.3',
                          'sqlparse==0.3.0'],
    )
