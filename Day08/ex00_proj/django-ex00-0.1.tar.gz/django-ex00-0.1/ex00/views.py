from django.shortcuts import render
from .models import Files
from .forms import FilesForm
from django.views.generic import ListView


def index(request):

    files = Files.objects.all()

    if request.method == 'POST':
        form = FilesForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
    else:
        form = FilesForm()
    return render(request, 'index.html', {'form': form, 'files': files})


class FileList(ListView):
    model = Files
    template_name = 'index.html'
